//Curtis Bauman
//Christopher Lit
//May 09 2022
package testquestion;

public class QuestionsTest {
    


    //Instance Variables
    private String answer;
    private String question;
    private int questionNum;
    private String a1;
    private String a2;
    private String a3;
    private String a4;

    //Constructors
    public QuestionsTest() {
        answer = "";
        question = "";
        questionNum = 0;
        a1 = "";
        a2 = "";
        a3 = "";
        a4 = "";
    }

    public QuestionsTest(String questionName, int questionNumber,
            String correctAnswer, String a1, String a2, String a3, String a4) {
        this();
        answer = correctAnswer;
        question = questionName;
        questionNum = questionNumber;
        this.a1 = a1;
        this.a2 = a2;
        this.a3 = a3;
        this.a4 = a4;
    }

    //Behavior and Methods
    //Getters
    public String getCorrectAnswer() {
        return answer;
    }

    public String getQuestion() {
        return question;
    }

    public String getA1() {
        return a1;
    }

    public String getA2() {
        return a2;
    }

    public String getA3() {
        return a3;
    }

    public String getA4() {
        return a4;
    }

    //Setters
    public void setCorrectAnswer(String answer) {
        this.answer = answer;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public void setA1(String a1) {
        this.a1 = a1;
    }

    public void setA2(String a2) {
        this.a2 = a2;
    }

    public void setA3(String a3) {
        this.a3 = a3;

    }

    public void setA4(String a4) {
        this.a4 = a4;
    }

    //Clone and Equals
    public TestQuestions clone(){
        TestQuestions q1;
        q1 = new TestQuestions(question, questionNum, answer, a1, a2, a3, a4);
        return q1;
    }
    public boolean equals(String q2){
        return this.answer.equals(q2);
    }
    
    
    
    //String
    public String toString() {
        String phrase = "";
        return phrase;
    }
}
